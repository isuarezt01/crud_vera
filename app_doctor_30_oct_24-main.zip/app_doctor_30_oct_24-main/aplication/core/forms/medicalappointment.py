from django.forms import ModelForm
from django import forms
from aplication.attention.models import CitaMedica

class CitaMedicaForm(ModelForm):
    class Meta:
        model = CitaMedica
        fields = ["paciente", "fecha", "hora_cita", "estado"]

        # Personalización de los widgets para los campos de CitaMedica
        widgets = {
            "paciente": forms.Select(
                attrs={
                    "id": "id_paciente",
                    "class": "shadow-sm bg-gray-50 border border-gray-300 text-gray-900 rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-principal dark:border-gray-600 dark:placeholder-gray-400 dark:text-gray-400 dark:focus:ring-blue-500 dark:focus:border-blue-500 dark:shadow-sm-light",
                }
            ),
            "fecha": forms.DateInput(
                attrs={
                    "placeholder": "Ingrese la fecha de la cita",
                    "id": "id_fecha",
                    "class": "shadow-sm bg-gray-50 border border-gray-300 text-gray-900 rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-principal dark:border-gray-600 dark:placeholder-gray-400 dark:text-gray-400 dark:focus:ring-blue-500 dark:focus:border-blue-500 dark:shadow-sm-light",
                    "type": "date",
                }
            ),
            "hora_cita": forms.TimeInput(
                attrs={
                    "placeholder": "Ingrese la hora de la cita",
                    "id": "id_hora_cita",
                    "class": "shadow-sm bg-gray-50 border border-gray-300 text-gray-900 rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-principal dark:border-gray-600 dark:placeholder-gray-400 dark:text-gray-400 dark:focus:ring-blue-500 dark:focus:border-blue-500 dark:shadow-sm-light",
                    "type": "time",
                }
            ),
            "estado": forms.Select(
                attrs={
                    "id": "id_estado",
                    "class": "shadow-sm bg-gray-50 border border-gray-300 text-gray-900 rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-principal dark:border-gray-600 dark:placeholder-gray-400 dark:text-gray-400 dark:focus:ring-blue-500 dark:focus:border-blue-500 dark:shadow-sm-light",
                }
            ),
        }

        labels = {
            "paciente": "Paciente",
            "fecha": "Fecha de la Cita",
            "hora_cita": "Hora de la Cita",
            "estado": "Estado de la Cita",
        }


    # Método de limpieza para validar el campo `nombre`
    def clean_nombre(self):
        nombre = self.cleaned_data.get("nombre")
        if not nombre or len(nombre) < 2:
            raise forms.ValidationError("El nombre del examen debe tener al menos 2 caracteres.")
        
        return nombre.capitalize()
