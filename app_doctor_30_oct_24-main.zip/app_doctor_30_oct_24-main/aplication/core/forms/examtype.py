from django.forms import ModelForm
from django import forms

from aplication.core.models import TipoCategoria

class TipoCategoriaExamenForm(ModelForm):
    class Meta:
        model = TipoCategoria
        fields = ["categoria_examen", "nombre", "descripcion", "valor_minimo", "valor_maximo", "activo"]

        # Personalización de los widgets y mensajes de error
        widgets = {
            "categoria_examen": forms.Select(
                attrs={
                    "id": "id_categoria_examen",
                    "class": "shadow-sm bg-gray-50 border border-gray-300 text-gray-900 rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-principal dark:border-gray-600 dark:placeholder-gray-400 dark:text-gray-400 dark:focus:ring-blue-500 dark:focus:border-blue-500 dark:shadow-sm-light",
                }
            ),
            "nombre": forms.TextInput(
                attrs={
                    "placeholder": "Ingrese el nombre del examen",
                    "id": "id_nombre",
                    "class": "shadow-sm bg-gray-50 border border-gray-300 text-gray-900 rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-principal dark:border-gray-600 dark:placeholder-gray-400 dark:text-gray-400 dark:focus:ring-blue-500 dark:focus:border-blue-500 dark:shadow-sm-light",
                }
            ),
            "descripcion": forms.Textarea(
                attrs={
                    "placeholder": "Ingrese una descripción (opcional)",
                    "id": "id_descripcion",
                    "class": "shadow-sm bg-gray-50 border border-gray-300 text-gray-900 rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-principal dark:border-gray-600 dark:placeholder-gray-400 dark:text-gray-400 dark:focus:ring-blue-500 dark:focus:border-blue-500 dark:shadow-sm-light",
                    "rows": 4,
                }
            ),
            "valor_minimo": forms.TextInput(
                attrs={
                    "placeholder": "Ingrese el valor mínimo de referencia",
                    "id": "id_valor_minimo",
                    "class": "shadow-sm bg-gray-50 border border-gray-300 text-gray-900 rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-principal dark:border-gray-600 dark:placeholder-gray-400 dark:text-gray-400 dark:focus:ring-blue-500 dark:focus:border-blue-500 dark:shadow-sm-light",
                }
            ),
            "valor_maximo": forms.TextInput(
                attrs={
                    "placeholder": "Ingrese el valor máximo de referencia",
                    "id": "id_valor_maximo",
                    "class": "shadow-sm bg-gray-50 border border-gray-300 text-gray-900 rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-principal dark:border-gray-600 dark:placeholder-gray-400 dark:text-gray-400 dark:focus:ring-blue-500 dark:focus:border-blue-500 dark:shadow-sm-light",
                }
            ),
            "activo": forms.CheckboxInput(
                attrs={
                    "class": "mt-1 block px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                }
            ),
        }

        labels = {
            "categoria_examen": "Categoría del Examen",
            "nombre": "Nombre del Examen",
            "descripcion": "Descripción del Examen",
            "valor_minimo": "Valor Mínimo",
            "valor_maximo": "Valor Máximo",
            "activo": "Activo",
        }

    # Método de limpieza para validar el campo `nombre`
    def clean_nombre(self):
        nombre = self.cleaned_data.get("nombre")
        if not nombre or len(nombre) < 2:
            raise forms.ValidationError("El nombre del examen debe tener al menos 2 caracteres.")
        
        return nombre.capitalize()
