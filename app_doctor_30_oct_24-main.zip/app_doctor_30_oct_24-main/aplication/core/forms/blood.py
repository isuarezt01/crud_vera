from django.forms import ModelForm
from django import forms

from aplication.core.models import TipoSangre

class TipoSangreForm(ModelForm):
    class Meta:
        model = TipoSangre
        fields = ["tipo", "descripcion"]

        # Personalización de los widgets y mensajes de error
        widgets = {
            "tipo": forms.TextInput(
                attrs={
                    "placeholder": "Ingrese el tipo de sangre (ej. A+, O-)",
                    "id": "id_tipo",
                    "class": "shadow-sm bg-gray-50 border border-gray-300 text-gray-900 rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 pr-12 dark:bg-principal dark:border-gray-600 dark:placeholder-gray-400 dark:text-gray-400 dark:focus:ring-blue-500 dark:focus:border-blue-500 dark:shadow-sm-light",
                }
            ),
            "descripcion": forms.Textarea(
                attrs={
                    "placeholder": "Ingrese una descripción (opcional)",
                    "id": "id_descripcion",
                    "class": "shadow-sm bg-gray-50 border border-gray-300 text-gray-900 rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 pr-12 dark:bg-principal dark:border-gray-600 dark:placeholder-gray-400 dark:text-gray-400 dark:focus:ring-blue-500 dark:focus:border-blue-500 dark:shadow-sm-light",
                    "rows": 4,
                }
            ),
            "activo": forms.CheckboxInput(
                attrs={
                    "class": "mt-1 block px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                }
            ),
        }

        labels = {
            "tipo": "Tipo de Sangre",
            "descripcion": "Descripción",
            "activo": "Activo",
        }

    # Método de limpieza para validar el tipo de sangre
    def clean_tipo(self):
        tipo = self.cleaned_data.get("tipo")
        # Verificar que el campo no esté vacío y tenga un formato válido
        if not tipo or len(tipo) < 2:
            raise forms.ValidationError("El tipo de sangre debe tener al menos 2 caracteres.")
        
        # Convertir a mayúsculas para uniformidad
        return tipo.upper()
