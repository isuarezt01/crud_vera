from django.urls import path
from aplication.core.views.home import HomeTemplateView
from aplication.core.views.patient import PatientCreateView, PatientDeleteView, PatientDetailView, PatientListView, PatientUpdateView
from aplication.core.views.blood import BloodCreateView, BloodDeleteView, BloodDetailView, BloodListView, BloodUpdateView
from aplication.core.views.diagnostic import DiagnosticCreateView, DiagnosticDeleteView, DiagnosticDetailView, DiagnosticListView, DiagnosticUpdateView
from aplication.core.views.exam import CategoriaExamCreateView, CategoriaExamDeleteView, CategoriaExamDetailView, CategoriaExamListView, CategoriaExamUpdateView
from aplication.core.views.examtype import TipoCatExamCreateView, TipoCatExamDeleteView, TipoCatExamDetailView, TipoCatExamListView, TipoCatExamUpdateView

from aplication.core.views.openinghours import HorarioAtencionCreateView, HorarioAtencionDeleteView, HorarioAtencionDetailView, HorarioAtencionListView, HorarioAtencionUpdateView
from aplication.core.views.medicalappointment import CitaMedicaCreateView, CitaMedicaDeleteView, CitaMedicaDetailView, CitaMedicaListView, CitaMedicaUpdateView
 
app_name='core' # define un espacio de nombre para la aplicacion
urlpatterns = [
  # ruta principal
  path('', HomeTemplateView.as_view(),name='home'),
  # rutas doctores VBF
  # path('doctor_list/', views.doctor_List,name="doctor_list"),
  # path('doctor_create/', views.doctor_create,name="doctor_create"),
  # path('doctor_update/<int:id>/', views.doctor_update,name='doctor_update'),
  # path('doctor_delete/<int:id>/', views.doctor_delete,name='doctor_delete'),
  # rutas doctores VBC
  path('patient_list/',PatientListView.as_view() ,name="patient_list"),
  path('patient_create/', PatientCreateView.as_view(),name="patient_create"),
  path('patient_update/<int:pk>/', PatientUpdateView.as_view(),name='patient_update'),
  path('patient_delete/<int:pk>/', PatientDeleteView.as_view(),name='patient_delete'),
  path('patient_detail/<int:pk>/', PatientDetailView.as_view(),name='patient_detail'),
  
  path('blood_list/', BloodListView.as_view(), name="blood_list"),
  path('blood_create/', BloodCreateView.as_view(), name="blood_create"),
  path('blood_update/<int:pk>/', BloodUpdateView.as_view(), name='blood_update'),
  path('blood_delete/<int:pk>/', BloodDeleteView.as_view(), name='blood_delete'),
  path('blood_detail/<int:pk>/', BloodDetailView.as_view(), name='blood_detail'),
  
  path('diagnostic_list/', DiagnosticListView.as_view(), name="diagnostic_list"),
  path('diagnostic_create/', DiagnosticCreateView.as_view(), name="diagnostic_create"),
  path('diagnostic_update/<int:pk>/', DiagnosticUpdateView.as_view(), name='diagnostic_update'),
  path('diagnostic_delete/<int:pk>/', DiagnosticDeleteView.as_view(), name='diagnostic_delete'),
  path('diagnostic_detail/<int:pk>/', DiagnosticDetailView.as_view(), name='diagnostic_detail'),
  
  path('exam_list/', CategoriaExamListView.as_view(), name="exam_list"),
  path('exam_create/', CategoriaExamCreateView.as_view(), name="exam_create"),
  path('exam_update/<int:pk>/', CategoriaExamUpdateView.as_view(), name='exam_update'),
  path('exam_delete/<int:pk>/', CategoriaExamDeleteView.as_view(), name='exam_delete'),
  path('exam_detail/<int:pk>/', CategoriaExamDetailView.as_view(), name='exam_detail'),
  
  path('examtype_list/', TipoCatExamListView.as_view(), name="examtype_list"),
  path('examtype_create/', TipoCatExamCreateView.as_view(), name="examtype_create"),
  path('examtype_update/<int:pk>/', TipoCatExamUpdateView.as_view(), name='examtype_update'),
  path('examtype_delete/<int:pk>/', TipoCatExamDeleteView.as_view(), name='examtype_delete'),
  path('examtype_detail/<int:pk>/', TipoCatExamDetailView.as_view(), name='examtype_detail'),
  
  path('horario_list/', HorarioAtencionListView.as_view(), name="horario_list"),
  path('horario_create/', HorarioAtencionCreateView.as_view(), name="horario_create"),
  path('horario_update/<int:pk>/', HorarioAtencionUpdateView.as_view(), name='horario_update'),
  path('horario_delete/<int:pk>/', HorarioAtencionDeleteView.as_view(), name='horario_delete'),
  path('horario_detail/<int:pk>/', HorarioAtencionDetailView.as_view(), name='horario_detail'),
  
  path('cita_list/', CitaMedicaListView.as_view(), name="cita_list"),
  path('cita_create/', CitaMedicaCreateView.as_view(), name="cita_create"),
  path('cita_update/<int:pk>/', CitaMedicaUpdateView.as_view(), name='cita_update'),
  path('cita_delete/<int:pk>/', CitaMedicaDeleteView.as_view(), name='cita_delete'),
  path('cita_detail/<int:pk>/', CitaMedicaDetailView.as_view(), name='cita_detail'),
]