from django.urls import reverse_lazy
from aplication.core.forms.medicalappointment import CitaMedicaForm
from aplication.attention.models import CitaMedica
from django.views.generic import CreateView, ListView, UpdateView, DeleteView, DetailView
from django.http import JsonResponse
from django.contrib import messages
from django.db.models import Q
from doctor.utils import save_audit

class CitaMedicaListView(ListView):
    template_name = "core/medicalappointment/list.html"
    model = CitaMedica
    context_object_name = 'cita_medica'
    paginate_by = 2
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['title'] = "Medical"
        context['title1'] = "Consulta de la Cita Medica"
        return context

class CitaMedicaCreateView(CreateView):
    model = CitaMedica
    template_name = 'core/medicalappointment/form.html'
    form_class = CitaMedicaForm
    success_url = reverse_lazy('core:cita_list')

    def get_context_data(self, **kwargs):
        context = super().get_context_data()
        context['title1'] = 'Cita Medica'
        context['save_text'] = 'Guardar Cita Medica'
        context['back_url'] = self.success_url
        return context
    
    def form_valid(self, form):
        response = super().form_valid(form)
        cita = self.object
        save_audit(self.request, cita, action='A')
        messages.success(self.request, f"Cita del paciente {cita.paciente} agendada.")
        return response
    
    def form_invalid(self, form):
        messages.error(self.request, "Error submitting the form. Please correct the errors.")
        return self.render_to_response(self.get_context_data(form=form))

class CitaMedicaUpdateView(UpdateView):
    model = CitaMedica
    template_name = 'core/medicalappointment/form.html'
    form_class = CitaMedicaForm
    success_url = reverse_lazy('core:cita_list')

    def get_context_data(self, **kwargs):
        context = super().get_context_data()
        context['save_text'] = 'Update Exam Type'
        context['back_url'] = self.success_url
        return context
    
    def form_valid(self, form):
        response = super().form_valid(form)
        cita = self.object
        save_audit(self.request, cita, action='M')
        messages.success(self.request, f"Cita Medica del paciente: {cita.paciente} actualizada.")
        return response
    
    def form_invalid(self, form):
        messages.error(self.request, "Error updating the form. Please correct the errors.")
        return self.render_to_response(self.get_context_data(form=form))

class CitaMedicaDeleteView(DeleteView):
    model = CitaMedica
    success_url = reverse_lazy('core:cita_list')

    def get_context_data(self, **kwargs):
        context = super().get_context_data()
        context['delete_text'] = 'Delete Exam Type'
        context['description'] = f"Seguro que desea eliminar la cita del paciente: {self.object.paciente}?"
        context['back_url'] = self.success_url
        return context
    
    def delete(self, request, *args, **kwargs):
        self.object = self.get_object()
        success_message = f"Cita medica del paciente: {self.object.paciente} ha sido borrada con exito."
        messages.success(self.request, success_message)
        return super().delete(request, *args, **kwargs)
    
class CitaMedicaDetailView(DetailView):
    model = CitaMedica
    
    def get(self, request, *args, **kwargs):
        cita = self.get_object()
        data = {
            'id': cita.id,
            'paciente': cita.paciente,
            'hora_cita': cita.hora_cita,
        }
        return JsonResponse(data)
