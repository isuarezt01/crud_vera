from django.urls import reverse_lazy
from aplication.core.forms.openinghours import HorarioAtencionForm
from aplication.attention.models import HorarioAtencion
from django.views.generic import CreateView, ListView, UpdateView, DeleteView, DetailView
from django.http import JsonResponse
from django.contrib import messages
from django.db.models import Q
from doctor.utils import save_audit

class HorarioAtencionListView(ListView):
    template_name = "core/openinghours/list.html"
    model = HorarioAtencion
    context_object_name = 'horario_atencion'
    paginate_by = 2
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['title'] = "Medical"
        context['title1'] = "Consulta de Tipos de Categoria de Examen"
        return context

class HorarioAtencionCreateView(CreateView):
    model = HorarioAtencion
    template_name = 'core/openinghours/form.html'
    form_class = HorarioAtencionForm
    success_url = reverse_lazy('core:horario_list')

    def get_context_data(self, **kwargs):
        context = super().get_context_data()
        context['title1'] = 'Categoria de Tipo de Examen'
        context['save_text'] = 'Guardar Categoria de Tipo de Examen'
        context['back_url'] = self.success_url
        return context
    
    def form_valid(self, form):
        response = super().form_valid(form)
        horario_atencion = self.object
        save_audit(self.request, horario_atencion, action='A')
        messages.success(self.request, f"Successfully created exam type {horario_atencion.dia_semana}.")
        return response
    
    def form_invalid(self, form):
        messages.error(self.request, "Error submitting the form. Please correct the errors.")
        return self.render_to_response(self.get_context_data(form=form))

class HorarioAtencionUpdateView(UpdateView):
    model = HorarioAtencion
    template_name = 'core/openinghours/form.html'
    form_class = HorarioAtencionForm
    success_url = reverse_lazy('core:horario_list')

    def get_context_data(self, **kwargs):
        context = super().get_context_data()
        context['save_text'] = 'Update Exam Type'
        context['back_url'] = self.success_url
        return context
    
    def form_valid(self, form):
        response = super().form_valid(form)
        horario_atencion = self.object
        save_audit(self.request, horario_atencion, action='M')
        messages.success(self.request, f"Successfully updated exam type {horario_atencion.dia_semana}.")
        return response
    
    def form_invalid(self, form):
        messages.error(self.request, "Error updating the form. Please correct the errors.")
        return self.render_to_response(self.get_context_data(form=form))

class HorarioAtencionDeleteView(DeleteView):
    model = HorarioAtencion
    success_url = reverse_lazy('core:horario_list')

    def get_context_data(self, **kwargs):
        context = super().get_context_data()
        context['delete_text'] = 'Delete Exam Type'
        context['description'] = f"Do you want to delete the exam type: {self.object.dia_semana}?"
        context['back_url'] = self.success_url
        return context
    
    def delete(self, request, *args, **kwargs):
        self.object = self.get_object()
        success_message = f"Successfully deleted exam type {self.object.dia_semana}."
        messages.success(self.request, success_message)
        return super().delete(request, *args, **kwargs)
    
class HorarioAtencionDetailView(DetailView):
    model = HorarioAtencion
    
    def get(self, request, *args, **kwargs):
        horario_atencion = self.get_object()
        data = {
            'id': horario_atencion.id,
            'dia_semana': horario_atencion.dia_semana,
            'hora_inicio': horario_atencion.hora_inicio,
            'hora_fin': horario_atencion.hora_fin,
            'Intervalo_desde': horario_atencion.Intervalo_desde,
            'Intervalo_hasta': horario_atencion.Intervalo_hasta,
        }
        return JsonResponse(data)
