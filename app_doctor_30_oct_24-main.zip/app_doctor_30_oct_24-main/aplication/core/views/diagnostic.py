from django.urls import reverse_lazy
from aplication.core.forms.diagnostic import DiagnosticForm
from aplication.core.models import Diagnostico
from django.views.generic import CreateView, ListView, UpdateView, DeleteView, DetailView
from django.http import JsonResponse
from django.contrib import messages
from django.db.models import Q
from doctor.utils import save_audit

class DiagnosticListView(ListView):
    template_name = "core/diagnostic/list.html"
    model = Diagnostico
    context_object_name = 'diagnostic'
    query = None
    paginate_by = 2
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['title'] = "Medical"
        context['title1'] = "Consulta de Diagnosticos del Paciente"
        return context

class DiagnosticCreateView(CreateView):
    model = Diagnostico
    template_name = 'core/diagnostic/form.html'
    form_class = DiagnosticForm
    success_url = reverse_lazy('core:diagnostic_list')

    def get_context_data(self, **kwargs):
        context = super().get_context_data()
        context['title1'] = 'Crear Diagnostico'
        context['save_text'] = 'Guardar Diagnostico'
        context['back_url'] = self.success_url
        return context
    
    def form_valid(self, form):
        response = super().form_valid(form)
        diagnostic_type = self.object
        save_audit(self.request, diagnostic_type, action='A')
        messages.success(self.request, f"Diagnostico del paciente {diagnostic_type.codigo} creado con exito.")
        return response
    
    def form_invalid(self, form):
        messages.error(self.request, "Error submitting the form. Please correct the errors.")
        return self.render_to_response(self.get_context_data(form=form))

class DiagnosticUpdateView(UpdateView):
    model = Diagnostico
    template_name = 'core/diagnostic/form.html'
    form_class = DiagnosticForm
    success_url = reverse_lazy('core:diagnostic_list')

    def get_context_data(self, **kwargs):
        context = super().get_context_data()
        context['save_text'] = 'Actualizar Diagnostico'
        context['back_url'] = self.success_url
        return context
    
    def form_valid(self, form):
        response = super().form_valid(form)
        diagnostic_type = self.object
        save_audit(self.request, diagnostic_type, action='M')
        messages.success(self.request, f"Se ha actualizado el diagnostico de {diagnostic_type.descripcion}.")
        return response
    
    def form_invalid(self, form):
        messages.error(self.request, "Error updating the form. Please correct the errors.")
        return self.render_to_response(self.get_context_data(form=form))

class DiagnosticDeleteView(DeleteView):
    model = Diagnostico
    success_url = reverse_lazy('core:diagnostic_list')

    def get_context_data(self, **kwargs):
        context = super().get_context_data()
        context['delete_text'] = 'Borrar Diagnostico'
        context['description'] = f"Estas seguro que deseas eliminar el diagnostico del paciente: {self.object.tipo}?"
        context['back_url'] = self.success_url
        return context
    
    def delete(self, request, *args, **kwargs):
        self.object = self.get_object()
        success_message = f"Se ha borrado con exito el diagnostico de {self.object.tipo}."
        messages.success(self.request, success_message)
        return super().delete(request, *args, **kwargs)
    
class DiagnosticDetailView(DetailView):
    model = Diagnostico
    
    def get(self, request, *args, **kwargs):
        blood_type = self.get_object()
        data = {
            'id': blood_type.id,
            'tipo': blood_type.tipo,
            'description': blood_type.descripcion,
            'active': blood_type.active,
        }
        return JsonResponse(data)
