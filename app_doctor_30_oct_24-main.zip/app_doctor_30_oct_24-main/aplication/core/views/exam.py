from django.urls import reverse_lazy
from aplication.core.forms.exam import CategoriaExamenForm
from aplication.core.models import CategoriaExamen
from django.views.generic import CreateView, ListView, UpdateView, DeleteView, DetailView
from django.http import JsonResponse
from django.contrib import messages
from django.db.models import Q
from doctor.utils import save_audit

class CategoriaExamListView(ListView):
    template_name = "core/exam/list.html"
    model = CategoriaExamen
    context_object_name = 'categoria_examen'
    query = None
    paginate_by = 2
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['title'] = "Medical"
        context['title1'] = "Consulta de Categoria de examen"
        return context

class CategoriaExamCreateView(CreateView):
    model = CategoriaExamen
    template_name = 'core/exam/form.html'
    form_class = CategoriaExamenForm
    success_url = reverse_lazy('core:exam_list')

    def get_context_data(self, **kwargs):
        context = super().get_context_data()
        context['title1'] = 'Crear Categoria de examen'
        context['save_text'] = 'Guardar categoria de examen'
        context['back_url'] = self.success_url
        return context
    
    def form_valid(self, form):
        response = super().form_valid(form)
        exam_type = self.object
        save_audit(self.request, exam_type, action='A')
        messages.success(self.request, f"Categoria {exam_type.nombre} creada con exito.")
        return response
    
    def form_invalid(self, form):
        messages.error(self.request, "Error al enviar el formulario. Por favor corrija los errores.")
        return self.render_to_response(self.get_context_data(form=form))

class CategoriaExamUpdateView(UpdateView):
    model = CategoriaExamen
    template_name = 'core/blood/form.html'
    form_class = CategoriaExamenForm
    success_url = reverse_lazy('core:exam_list')

    def get_context_data(self, **kwargs):
        context = super().get_context_data()
        context['save_text'] = 'Actualizar Categoria de Examen'
        context['back_url'] = self.success_url
        return context
    
    def form_valid(self, form):
        response = super().form_valid(form)
        blood_type = self.object
        save_audit(self.request, blood_type, action='M')
        messages.success(self.request, f"Categoria de examen actualizado con éxito {blood_type.nombre}.")
        return response
    
    def form_invalid(self, form):
        messages.error(self.request, "Error al actualizar el formulario. Por favor corrija los errores.")
        return self.render_to_response(self.get_context_data(form=form))

class CategoriaExamDeleteView(DeleteView):
    model = CategoriaExamen
    success_url = reverse_lazy('core:exam_list')

    def get_context_data(self, **kwargs):
        context = super().get_context_data()
        context['delete_text'] = 'Borrar Categoria de Examen'
        context['description'] = f"¿Quieres eliminar la categoria de examen: {self.object.nombre}?"
        context['back_url'] = self.success_url
        return context
    
    def delete(self, request, *args, **kwargs):
        self.object = self.get_object()
        success_message = f"Se eliminó correctamente la categoria de examen {self.object.nombre}."
        messages.success(self.request, success_message)
        return super().delete(request, *args, **kwargs)
    
class CategoriaExamDetailView(DetailView):
    model = CategoriaExamen
    
    def get(self, request, *args, **kwargs):
        blood_type = self.get_object()
        data = {
            'id': blood_type.id,
            'nombre': blood_type.nombre,
            'description': blood_type.descripcion,
            'active': blood_type.active,
            # Add more fields based on your Blood model as needed
        }
        return JsonResponse(data)
