from django.urls import reverse_lazy
from aplication.core.forms.examtype import TipoCategoriaExamenForm
from aplication.core.models import TipoCategoria
from django.views.generic import CreateView, ListView, UpdateView, DeleteView, DetailView
from django.http import JsonResponse
from django.contrib import messages
from django.db.models import Q
from doctor.utils import save_audit

class TipoCatExamListView(ListView):
    template_name = "core/examtype/list.html"
    model = TipoCategoria
    context_object_name = 'examen_tipos'
    paginate_by = 2
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['title'] = "Medical"
        context['title1'] = "Consulta de Tipos de Categoria de Examen"
        return context

class TipoCatExamCreateView(CreateView):
    model = TipoCategoria
    template_name = 'core/examtype/form.html'
    form_class = TipoCategoriaExamenForm
    success_url = reverse_lazy('core:examtype_list')

    def get_context_data(self, **kwargs):
        context = super().get_context_data()
        context['title1'] = 'Categoria de Tipo de Examen'
        context['save_text'] = 'Guardar Categoria de Tipo de Examen'
        context['back_url'] = self.success_url
        return context
    
    def form_valid(self, form):
        response = super().form_valid(form)
        exam_type = self.object
        save_audit(self.request, exam_type, action='A')
        messages.success(self.request, f"Successfully created exam type {exam_type.nombre}.")
        return response
    
    def form_invalid(self, form):
        messages.error(self.request, "Error submitting the form. Please correct the errors.")
        return self.render_to_response(self.get_context_data(form=form))

class TipoCatExamUpdateView(UpdateView):
    model = TipoCategoria
    template_name = 'core/examtype/form.html'
    form_class = TipoCategoriaExamenForm
    success_url = reverse_lazy('core:examtype_list')

    def get_context_data(self, **kwargs):
        context = super().get_context_data()
        context['save_text'] = 'Update Exam Type'
        context['back_url'] = self.success_url
        return context
    
    def form_valid(self, form):
        response = super().form_valid(form)
        exam_type = self.object
        save_audit(self.request, exam_type, action='M')
        messages.success(self.request, f"Successfully updated exam type {exam_type.nombre}.")
        return response
    
    def form_invalid(self, form):
        messages.error(self.request, "Error updating the form. Please correct the errors.")
        return self.render_to_response(self.get_context_data(form=form))

class TipoCatExamDeleteView(DeleteView):
    model = TipoCategoria
    success_url = reverse_lazy('core:examtype_list')

    def get_context_data(self, **kwargs):
        context = super().get_context_data()
        context['delete_text'] = 'Delete Exam Type'
        context['description'] = f"Do you want to delete the exam type: {self.object.nombre}?"
        context['back_url'] = self.success_url
        return context
    
    def delete(self, request, *args, **kwargs):
        self.object = self.get_object()
        success_message = f"Successfully deleted exam type {self.object.nombre}."
        messages.success(self.request, success_message)
        return super().delete(request, *args, **kwargs)
    
class TipoCatExamDetailView(DetailView):
    model = TipoCategoria
    
    def get(self, request, *args, **kwargs):
        exam_type = self.get_object()
        data = {
            'id': exam_type.id,
            'nombre': exam_type.nombre,
            'descripcion': exam_type.descripcion,
            'valor_minimo': exam_type.valor_minimo,
            'valor_maximo': exam_type.valor_maximo,
            'activo': exam_type.activo,
        }
        return JsonResponse(data)
