from django.urls import reverse_lazy
from aplication.core.forms.blood import TipoSangreForm
from aplication.core.models import TipoSangre
from django.views.generic import CreateView, ListView, UpdateView, DeleteView, DetailView
from django.http import JsonResponse
from django.contrib import messages
from django.db.models import Q
from doctor.utils import save_audit

class BloodListView(ListView):
    template_name = "core/blood/list.html"
    model = TipoSangre
    context_object_name = 'blood_tipos'
    query = None
    paginate_by = 2
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['title'] = "Medical"
        context['title1'] = "Consulta de Tipos de Sangre"
        return context

class BloodCreateView(CreateView):
    model = TipoSangre
    template_name = 'core/blood/form.html'
    form_class = TipoSangreForm
    success_url = reverse_lazy('core:blood_list')

    def get_context_data(self, **kwargs):
        context = super().get_context_data()
        context['title1'] = 'Create Blood Type'
        context['save_text'] = 'Save Blood Type'
        context['back_url'] = self.success_url
        return context
    
    def form_valid(self, form):
        response = super().form_valid(form)
        blood_type = self.object
        save_audit(self.request, blood_type, action='A')
        messages.success(self.request, f"Successfully created blood type {blood_type.tipo}.")
        return response
    
    def form_invalid(self, form):
        messages.error(self.request, "Error submitting the form. Please correct the errors.")
        return self.render_to_response(self.get_context_data(form=form))

class BloodUpdateView(UpdateView):
    model = TipoSangre
    template_name = 'core/blood/form.html'
    form_class = TipoSangreForm
    success_url = reverse_lazy('core:blood_list')

    def get_context_data(self, **kwargs):
        context = super().get_context_data()
        context['save_text'] = 'Update Blood Type'
        context['back_url'] = self.success_url
        return context
    
    def form_valid(self, form):
        response = super().form_valid(form)
        blood_type = self.object
        save_audit(self.request, blood_type, action='M')
        messages.success(self.request, f"Successfully updated blood type {blood_type.tipo}.")
        return response
    
    def form_invalid(self, form):
        messages.error(self.request, "Error updating the form. Please correct the errors.")
        return self.render_to_response(self.get_context_data(form=form))

class BloodDeleteView(DeleteView):
    model = TipoSangre
    success_url = reverse_lazy('core:blood_list')

    def get_context_data(self, **kwargs):
        context = super().get_context_data()
        context['delete_text'] = 'Delete Blood Type'
        context['description'] = f"Do you want to delete the blood type: {self.object.tipo}?"
        context['back_url'] = self.success_url
        return context
    
    def delete(self, request, *args, **kwargs):
        self.object = self.get_object()
        success_message = f"Successfully deleted blood type {self.object.tipo}."
        messages.success(self.request, success_message)
        return super().delete(request, *args, **kwargs)
    
class BloodDetailView(DetailView):
    model = TipoSangre
    
    def get(self, request, *args, **kwargs):
        blood_type = self.get_object()
        data = {
            'id': blood_type.id,
            'tipo': blood_type.tipo,
            'description': blood_type.descripcion,
            'active': blood_type.active,
            # Add more fields based on your Blood model as needed
        }
        return JsonResponse(data)
